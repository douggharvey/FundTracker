package com.douglasharvey.fundtracker3.data

import android.arch.lifecycle.LiveData
import android.arch.persistence.room.Dao
import android.arch.persistence.room.Insert
import android.arch.persistence.room.OnConflictStrategy
import android.arch.persistence.room.Query

@Dao
interface FundPriceDao {
    @Query("SELECT * FROM fund_prices ORDER BY fund_code")
    fun getFundValues(): LiveData<List<FundPrice>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(fundValue: FundPrice): Long

    @Query("DELETE FROM fund_prices WHERE fund_code =:recordId")
    fun delete(recordId: String)

}
