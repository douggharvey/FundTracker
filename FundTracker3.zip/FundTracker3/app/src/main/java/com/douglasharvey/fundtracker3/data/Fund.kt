package com.douglasharvey.fundtracker3.data

import android.arch.persistence.room.ColumnInfo
import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey

@Entity(tableName = "fund")
data class Fund(
        @PrimaryKey @ColumnInfo(name = "fund_code") val fundCode: String,
        @ColumnInfo(name = "fund_name") val fundName: String
//        @ColumnInfo(name = "favourite", index = true) val favourite: kotlin.Int // TODO index on favourites
)