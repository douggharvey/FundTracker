package com.douglasharvey.fundtracker3.data

import android.arch.lifecycle.LiveData
import android.arch.persistence.room.*

@Dao
interface FundDao {
    @DatabaseView
    @SuppressWarnings(RoomWarnings.CURSOR_MISMATCH)
    @Query("SELECT fund.fund_code, fund.fund_name, ?? FROM fund ORDER BY fund.fund_code") //todo join to favourites to get 0 or 1
    fun getFunds(): LiveData<List<FundList>>

    //todo how to structure the database so that columns can be returned in a valid way for room and meaningful way for adapter. try to avoid using @Ignore notation on FundList
    @SuppressWarnings(RoomWarnings.CURSOR_MISMATCH)
    @Query("SELECT fund.fund_code, fund.fund_name, favourite.fund_code FROM fund, favourite WHERE fund.fund_code = favourite.fund_code ORDER BY fund.fund_code")
    fun getFavourites(): LiveData<List<FundList>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(fund: Fund): Long

//    @Query("DELETE FROM fund WHERE fund_code =:recordId")/
//    fun delete(recordId: String)

//    @Query("UPDATE fund SET favourite = :favouriteflag WHERE fund_code =:fundCode")
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertFavourite(favourite: Favourite)

    @Query("DELETE FROM favourite WHERE fund_code =:fundCode")
    fun deleteFavourite(fundCode: String)

}