package com.douglasharvey.fundtracker3.data

import android.arch.persistence.room.ColumnInfo
import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey
@Entity(tableName = "fund_list")
data class FundList(
        @PrimaryKey @ColumnInfo(name = "fund_code") var fundCode: String,
        @ColumnInfo(name = "fund_name") var fundName: String,
        //@Ignore
        @ColumnInfo(name = "favourite") var favourite: String
){
        constructor() : this("", "", "")
}