package com.douglasharvey.fundtracker3.data

import android.arch.persistence.room.Database
import android.arch.persistence.room.Room
import android.arch.persistence.room.RoomDatabase
import android.content.Context

//todo add separate table for favourites
@Database(entities = arrayOf(
        Fund::class,
        FundPrice::class,
        Favourite::class
),
        version = 4, exportSchema = false)
abstract class FundsRoomDatabase : RoomDatabase() {
    abstract fun fundDao(): FundDao
    abstract fun fundPricesDao(): FundPriceDao

    companion object {

        private var INSTANCE: FundsRoomDatabase? = null

        internal fun getDatabase(context: Context): FundsRoomDatabase {
            if (INSTANCE == null) {
                synchronized(FundsRoomDatabase::class.java) {
                    if (INSTANCE == null) {
                        INSTANCE = Room.databaseBuilder(context.applicationContext,
                                FundsRoomDatabase::class.java, "funds_database")
                                .fallbackToDestructiveMigration() //todo temporary
                                .build()
                    }
                }
            }
            return INSTANCE!!
        }
    }

}
    
